using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputSystemLook : MonoBehaviour
{

    public Transform cameraRig;
    public float mouseSensivity;
    private float rigAngle = 0f;

    /*
    private void OnLookEvent(context)
    {
        if (false == SimpleMouseControl.isFocusing) return;
        look()
    }

    */

    private void OnLook(InputValue value)
    {

//        Vector2 lookValue = GetComponent<Vector2>();
        print($"OnLook ȣ�� �� : {value.Get<Vector2>()}");

//        if (false == SimpleMouseControl.isFOcusing) return;
        //esc �����ų� ��Ŀ�� ����� ���콺 �ν� ����

        Vector2 mouseDelta = value.Get<Vector2>();
        //transform.Rotate();
        transform.Rotate(0, mouseDelta.x * mouseSensivity * Time.deltaTime, 0);
        rigAngle -= mouseDelta.y * mouseSensivity * Time.deltaTime;
        rigAngle = Mathf.Clamp(rigAngle, -90f, 90f);
        cameraRig.localEulerAngles = new Vector3(rigAngle, 0, 0);

    }

}
