using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SimpleMouseControl : MonoBehaviour
{

    // public float OnApplicationFocus;

    private void Start()
    {
       // OnApplicationFocus(true);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
        //    OnApplicationFocus(false);
        }
        else if (Input.anyKeyDown)
        {
          //  OnApplicationFocus(true);
        };
        
    }

    public static bool isFocusing = true;

}
